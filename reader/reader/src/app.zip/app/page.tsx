export default function HomePage() {
  return (
    <main className="min-h-screen flex items-center justify-center">
      <h1 className="text-3xl font-bold">
        .15 Chronicles — Reader
      </h1>
    </main>
  );
}
