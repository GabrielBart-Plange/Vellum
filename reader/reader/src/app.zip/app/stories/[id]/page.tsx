import { doc, getDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { notFound } from "next/navigation";

export default async function StoryPage({
  params,
}: {
  params: { id: string };
}) {
  const ref = doc(db, "shortStories", params.id);
  const snap = await getDoc(ref);

  if (!snap.exists()) return notFound();

  const story = snap.data();

  return (
    <main className="max-w-3xl mx-auto p-8 space-y-6">
      <h1 className="text-2xl">{story.title}</h1>
      <p className="text-sm text-gray-500">
        by {story.authorName}
      </p>

      <article className="whitespace-pre-wrap leading-relaxed">
        {story.content}
      </article>
    </main>
  );
}
