import { collection, getDocs, orderBy, query } from "firebase/firestore";
import { db } from "@/lib/firebase";
import Link from "next/link";

export default async function ShortStoriesPage() {
  const ref = collection(db, "shortStories");
  const q = query(ref, orderBy("publishedAt", "desc"));
  const snap = await getDocs(q);

  return (
    <main className="max-w-3xl mx-auto p-8 space-y-6">
      <h1 className="tracking-widest">Short Stories</h1>

      {snap.docs.map((doc) => (
        <Link
          key={doc.id}
          href={`/short-stories/${doc.id}`}
          className="block border p-4 hover:bg-gray-900"
        >
          <h2>{doc.data().title}</h2>
          <p className="text-xs text-gray-500">
            by {doc.data().authorName}
          </p>
        </Link>
      ))}
    </main>
  );
}
